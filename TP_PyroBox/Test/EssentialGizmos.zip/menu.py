"""Copyright (c) 2023 Tim Adams

Permission is hereby granted, free of charge, to any person obtaining
a copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be
included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE."""

import nuke

toolbar = nuke.toolbar("Nodes")
m = toolbar.addMenu("TIM", icon="tim.png")

m = toolbar.addMenu("TIM/Color", icon="ToolbarColor.png")
m.addCommand("FixNegative", "nuke.createNode('FixNegative')", icon="RolloffContrast.png")

m = toolbar.addMenu("TIM/Filter", icon="ToolbarFilter.png")
m.addCommand("Halation", "nuke.createNode('Halation')", icon="Glow.png")
m.addCommand("LightBlur", "nuke.createNode('LightBlur')", icon="Light.png")
m.addCommand("RGBErode", "nuke.createNode('RGBErode')", icon="FilterErode.png")

m = toolbar.addMenu("TIM/Merge", icon="ToolbarMerge.png")
m.addCommand("DifferenceMatte", "nuke.createNode('DifferenceMatte')", icon="MergeDifference.png")
m.addCommand("LogMerge", "nuke.createNode('LogMerge')", icon="ToolbarMerge.png")
m.addCommand("UsePrecomp", "nuke.createNode('UsePrecomp')", icon="Switch.png")

m = toolbar.addMenu("TIM/Time", icon="ToolbarTime.png")
m.addCommand("FlickerGenerator", "nuke.createNode('FlickerGenerator')", icon="ParticleCurve.png")
m.addCommand("FrameFix", "nuke.createNode('FrameFix')", icon="FrameBlend.png")

m = toolbar.addMenu("TIM/Transform", icon="ToolbarTransform.png")
m.addCommand("CropOverscan", "nuke.createNode('CropOverscan')", icon="AdjBBox.png")
m.addCommand("TrackReformat", "nuke.createNode('TrackReformat')", icon="Tracker.png")

m = toolbar.addMenu("TIM/Utilities", icon="MetaData.png")
m.addCommand("GizmoTemplate", "nuke.createNode('GizmoTemplate')", icon="ToolsetCreate.png")
m.addCommand("HyperfocalDistance", "nuke.createNode('HyperfocalDistance')", icon="Defocus.png")

m = toolbar.addMenu("TIM/QC", icon="ColorMult.png")
m.addCommand("GrainBalance", "nuke.createNode('GrainBalance')", icon="Grain.png")