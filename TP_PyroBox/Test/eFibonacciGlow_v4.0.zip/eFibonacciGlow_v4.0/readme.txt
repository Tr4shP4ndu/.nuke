eFibonacciGlow v4.0



- Switch between Fibonacci and Tribonacci Exponential
- switch-format bug fixed

- color tint added




1. Copy the folder "eTools" in your .nuke folder (under C:/Users/...)

2. Add the following lines to your init.py file (right click and edit ) :

nuke.pluginAddPath('./eTools')

nuke.pluginAddPath('./eTools/Icons')
nuke.pluginAddPath('./eTools/Gizmos')


3. Add the following lines to your menu.py file (right click and edit ) :

toolbar = nuke.menu('Nodes')
eMenu = toolbar.addMenu('eTools', icon='eTools.png')
eMenu.addCommand('eFibonacciGlow', 'nuke.createNode("eFibonacciGlow")', icon='eFibonacciGlow.png')


Please share and visit my website: ermesvincenti.wordpress.com