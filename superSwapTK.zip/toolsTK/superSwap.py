#
# Python code by Timur Khodzhaev
#
#  www.vfxtim.com
#  chimuru@gmail.com
#

import nuke
import nukescripts

def superSwap():

    nodes=nuke.selectedNodes()

    if len(nodes)>0:
        for node in nodes:

            nodeClass=node.Class()

            canHandle=[
                    'Grade','Transform','Ramp','Shuffle1','CornerPin2D','Mirror','Mirror2','FrameHold',
                    'Blur', 'Colorspace', 'Tracker4', 'TimeOffset', 'OCIOColorSpace','BackdropNode'
            ]

            if nodeClass=='Grade':
                        node['reverse'].setValue( ((node['reverse'].getValue()+1)%2) )

            elif nodeClass=='Transform':
                node['invert_matrix'].setValue( ((node['invert_matrix'].getValue()+1)%2) )

            elif nodeClass=='Ramp':
                temp=node['p0'].getValue()
                node['p0'].setValue(node['p1'].getValue())
                node['p1'].setValue(temp)

            elif nodeClass=='Shuffle1':
                tileColor=[2369864191,1032143871,962307071,2341178367]
                index=int(node['red'].getValue())
                node['green'].setValue(index)
                node['blue'].setValue(index)
                node['alpha'].setValue(index)
                node['tile_color'].setValue(tileColor[index-1])

            elif node.Class()=='CornerPin2D':
                node['invert'].setValue( ((node['invert'].getValue()+1)%2) )

            elif nodeClass== 'Mirror':
                node['Horizontal'].setValue( ((node['Horizontal'].getValue()+1)%2) )
                node['Vertical'].setValue(1-node['Horizontal'].getValue())
                if node['Horizontal'].getValue():
                    node['label'].setValue('Horizontal')
                else:
                    node['label'].setValue('Vertical')

            elif nodeClass== 'Mirror2':
                node['flip'].setValue( ((node['flip'].getValue()+1)%2) )
                node['flop'].setValue(1-node['flop'].getValue())
                if node['flop'].getValue():
                    node['label'].setValue('Horizontal')
                else:
                    node['label'].setValue('Vertical')

            elif nodeClass=='FrameHold':
                node['first_frame'].setValue(nuke.frame())

            elif nodeClass=='TimeOffset':
                node['time_offset'].setValue(nuke.frame())

            elif nodeClass=='Tracker4':
                node['reference_frame'].setValue(nuke.frame())

            elif nodeClass=='Blur':
                if node['channels'].value()=='all':
                    node['channels'].setValue('alpha')
                elif node['channels'].value()=='alpha':
                    node['channels'].setValue('all')

            elif nodeClass=='Colorspace':
                colorspace_in=node['colorspace_in'].value()
                illuminant_in=node['illuminant_in'].value()
                primary_in=node['primary_in'].value()

                node['colorspace_in'].setValue(node['colorspace_out'].value())
                node['illuminant_in'].setValue(node['illuminant_out'].value())
                node['primary_in'].setValue(node['primary_out'].value())

                node['colorspace_out'].setValue(colorspace_in)
                node['illuminant_out'].setValue(illuminant_in)
                node['primary_out'].setValue(primary_in)

                node['label'].setValue('%s -> %s' % (node['colorspace_in'].value(),node['colorspace_out'].value()))

            elif nodeClass=='OCIOColorSpace':
                colorspace_in=node['in_colorspace'].value()
                node['in_colorspace'].setValue(node['out_colorspace'].value())
                node['out_colorspace'].setValue(colorspace_in)

                node['label'].setValue('%s -> %s' % (node['in_colorspace'].value(),node['out_colorspace'].value()))

            elif nodeClass=='BackdropNode':
                ndx=node['appearance'].values()
                node['appearance'].setValue( ndx[((ndx.index(node['appearance'].value())+1)%2)] )

            else:
                 nukescripts.swapAB(node)
