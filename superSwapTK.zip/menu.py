# superSwapTK
n = nuke.menu("Nodes").addMenu('toolsTK', icon='toolsTK.png')
n.addCommand("Organization/superSwapTK", 'from toolsTK.superSwap import superSwap; superSwap()')

ssMenu=nuke.menu("Nuke").findItem('Edit')
ssMenu.addCommand("Node/superSwap A - B", 'from toolsTK.superSwap import superSwap; superSwap()',"+x")